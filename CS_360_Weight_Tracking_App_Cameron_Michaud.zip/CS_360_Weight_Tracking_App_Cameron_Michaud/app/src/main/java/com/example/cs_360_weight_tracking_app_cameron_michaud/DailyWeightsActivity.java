package com.example.cs_360_weight_tracking_app_cameron_michaud;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class DailyWeightsActivity extends AppCompatActivity {


    BottomNavigationView bottomNavigationView;
    private ListView dailyWeightView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.daily_weights);

        initWidgets();

        if (Cell.cellArrayList.size() != 0) {Cell.cellArrayList.clear();};
        loadDB();

        // Populate ListView
        setCellAdapter();

        // Setup on-click for selecting entry
        setOnClickListener();
    }

    private void setOnClickListener() {
        Log.d("POPULATE", "Click");
        dailyWeightView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Log.d("POPULATE", "Clack");
                Cell selectedCell = (Cell) dailyWeightView.getItemAtPosition(position);
                Intent editCellIntent = new Intent(getApplicationContext(), WeightDetailActivity.class);
                editCellIntent.putExtra(Cell.WEIGHT_EDIT_EXTRA, selectedCell.getId());
                startActivity(editCellIntent);
            }
        });
    }

    private void loadDB() {
        Log.d("POPULATE", "____LOADING DATABASE____");
        WeightManager sqLiteManager = WeightManager.instanceOfDatabase(this);
        sqLiteManager.populateDailyWeightsArray();
    }

    private void setCellAdapter() {
        Log.d("POPULATE", "____POPULATING LISTVIEW____");
        CellAdapter cellAdapter = new CellAdapter(getApplicationContext(), Cell.nonDeletedCells());
        dailyWeightView.setAdapter(cellAdapter);
    }

    private void initWidgets() {
        dailyWeightView = findViewById(R.id.dailyWeightView);
        bottomNavigationView = findViewById(R.id.bottom_nav);
        bottomNavigationView.setSelectedItemId(R.id.dailyWeightScreen);

        bottomNavigationView.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.homeScreen) {
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0,0);
                    return true;
                }
                else if (item.getItemId() == R.id.dailyWeightScreen) {
                    return true;
                }
                else if (item.getItemId() == R.id.goalWeightScreen) {
                    startActivity(new Intent(getApplicationContext(), GoalActivity.class));
                    overridePendingTransition(0,0);
                    return true;
                }

                return false;
            }
        });
    }

    public void newWeight(View view) {
        Intent newWeightIntent = new Intent(this, WeightDetailActivity.class);
        startActivity(newWeightIntent);
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        setCellAdapter();
    }
}