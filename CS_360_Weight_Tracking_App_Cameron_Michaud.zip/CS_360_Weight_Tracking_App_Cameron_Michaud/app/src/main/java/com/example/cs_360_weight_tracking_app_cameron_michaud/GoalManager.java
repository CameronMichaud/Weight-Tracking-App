package com.example.cs_360_weight_tracking_app_cameron_michaud;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class GoalManager extends SQLiteOpenHelper {

    private static GoalManager sqLiteManager;
    private static final String DATABASE_NAME = "GoalWeightsDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "GoalWeights";
    private static final String COUNTER = "Counter";
    private static final String GOALWEIGHT_FIELD = "goalweight";

    private static final String USERNAME_FIELD = "username";


    public GoalManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static GoalManager instanceOfDatabase(Context context) {
        if (sqLiteManager == null)
            sqLiteManager = new GoalManager(context);

        return sqLiteManager;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(GOALWEIGHT_FIELD)
                .append(" TEXT, ")
                .append(USERNAME_FIELD)
                .append(" TEXT)");

        sqLiteDatabase.execSQL(sql.toString());


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {

    }

    public void addGoalWeightToDatabase(GoalWeight gWeight) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Log.d("FIELD", "ADDING GoalWeight");
        ContentValues contentValues = new ContentValues();
        contentValues.put(GOALWEIGHT_FIELD, gWeight.getGoalWeight());
        Log.d("FIELD", "GOALWEIGHT: " + gWeight.getGoalWeight());
        contentValues.put(USERNAME_FIELD, gWeight.getUsername());
        Log.d("FIELD", "USERNAME: " + gWeight.getUsername());

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
    }

    public GoalWeight getGoal() {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        GoalWeight rejected = new GoalWeight("null", "null");

        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null)) {
            if (result.getCount() != 0) {
                result.moveToLast();

                String weight = result.getString(1);
                String user = result.getString(2);

                return new GoalWeight(weight, user);
            }
        }
        return rejected;
    }

    public void removeGoal(String goal) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Log.d("Database", "Goal: " + goal);

        sqLiteDatabase.delete(TABLE_NAME, "GoalWeight=?", new String[]{String.valueOf(goal)});

        sqLiteDatabase.close();
    }
}
