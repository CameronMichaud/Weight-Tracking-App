package com.example.cs_360_weight_tracking_app_cameron_michaud;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class WeightManager extends SQLiteOpenHelper {

    private static WeightManager sqLiteManager;
    private static final String DATABASE_NAME = "WeightsDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "DailyWeights";
    private static final String COUNTER = "Counter";

    private static final String ID_FIELD = "id";
    private static final String DATE_FIELD = "date";
    private static final String WEIGHT_FIELD = "weight";
    private static final String DELETED_FIELD = "deleted";

    private static final String USERNAME_FIELD = "username";

    // DELETE ME: private static final DateFormat dateFormat = new SimpleDateFormat("MM--dd--yy HH--mm--ss");

    public WeightManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static WeightManager instanceOfDatabase(Context context) {
        if(sqLiteManager == null)
            sqLiteManager = new WeightManager(context);

        return sqLiteManager;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(ID_FIELD)
                .append(" INT, ")
                .append(DATE_FIELD)
                .append(" TEXT, ")
                .append(WEIGHT_FIELD)
                .append(" TEXT, ")
                .append(DELETED_FIELD)
                .append(" TEXT, ")
                .append(USERNAME_FIELD)
                .append(" TEXT)");

        sqLiteDatabase.execSQL(sql.toString());



    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {

    }

    public void addWeightToDatabase(Cell cell) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Log.d("FIELD", "ADDING WEIGHT");
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, cell.getId());
        Log.d("FIELD", "ID: " + cell.getId());
        contentValues.put(DATE_FIELD, cell.getDate());
        Log.d("FIELD", "DATE: " + cell.getDate());
        contentValues.put(WEIGHT_FIELD, cell.getWeight());
        Log.d("FIELD", "WEIGHT: " + cell.getWeight());
        contentValues.put(DELETED_FIELD, cell.getDeleted());
        Log.d("FIELD", "DELETED: " + cell.getDeleted());
        contentValues.put(USERNAME_FIELD, cell.getUser());
        Log.d("FIELD", "USERNAME: " + cell.getUser());

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
    }

    public void populateDailyWeightsArray() {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        // Clear array, later iterations should use better solutions
        //Cell.cellArrayList.clear();

        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null)) {
            if(result.getCount() != 0) {
                while (result.moveToNext())
                {
                    int id = result.getInt(1);
                    String date = result.getString(2);
                    String weight = result.getString(3);
                    String deleted = result.getString(4);
                    String username = result.getString(5);

                    // Create new weight & add to AdapterArray
                    Cell newWeight = new Cell(id, date, weight, deleted, username);
                    Log.d("FIELD", "newWeight::::;");
                    Cell.cellArrayList.add(newWeight);
                }
            }
        }
    }

    public void updateWeightInDatabase(Cell cell) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, cell.getId());
        Log.d("FIELD", "ID: " + cell.getId());
        contentValues.put(DATE_FIELD, cell.getDate());
        Log.d("FIELD", "DATE: " + cell.getDate());
        contentValues.put(WEIGHT_FIELD, cell.getWeight());
        Log.d("FIELD", "WEIGHT: " + cell.getWeight());
        contentValues.put(DELETED_FIELD, cell.getDeleted());
        Log.d("FIELD", "DELETED: " + cell.getDeleted());
        contentValues.put(USERNAME_FIELD, cell.getUser());
        Log.d("FIELD", "USERNAME: " + cell.getUser());

        sqLiteDatabase.update(TABLE_NAME, contentValues, ID_FIELD + " =? ", new String[]{String.valueOf(cell.getId())});
    }

    public String getWeight(String user) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Log.d("Database", "user: " + user);

        String rejected = "";

        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null)) {
            if (result.getCount() != 0) { // If data exists, check the last record
                result.moveToLast();
                String weight = result.getString(3);
                String username = result.getString(5);
                Log.d("Database", "weight: " + weight);
                Log.d("Database", "USERNAME: " + username);

                if (username.equals(user)) {
                    Log.d("Database", "Returning weight: " + weight);
                    return weight;
                }

                while (result.moveToPrevious()) { // if most recent weight not found first, iterate back
                    weight = result.getString(3);
                    username = result.getString(5);
                    Log.d("Database", "weight: " + weight);
                    Log.d("Database", "USERNAME: " + username);


                    if (username.equals(user)) {
                        Log.d("Database", "Returning weight: " + weight);
                        return weight;
                    }
                }
            }
            return rejected;
        }
    }

    public void removeWeightInDatabse(Cell cell) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Log.d("Database", "id: " + cell.getId());

        sqLiteDatabase.delete(TABLE_NAME, "id=?", new String[]{String.valueOf(cell.getId())});
        Log.d("Database", "id: " + cell.getId());

        sqLiteDatabase.close();

    }
}
