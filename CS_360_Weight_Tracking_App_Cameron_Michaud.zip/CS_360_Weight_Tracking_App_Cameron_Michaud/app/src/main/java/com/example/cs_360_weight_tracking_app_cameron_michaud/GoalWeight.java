package com.example.cs_360_weight_tracking_app_cameron_michaud;

import java.util.ArrayList;

public class GoalWeight {
    public static ArrayList<GoalWeight> cellArrayList = new ArrayList<>();

    private String goalWeight;
    private String username;

    //DELETE ME: public static String PASSWORD_EDIT_EXTRA = "PasswordEdit";

    public GoalWeight(String goalWeight, String username) {
        this.goalWeight = goalWeight;
        this.username = username;
    }

    public String getGoalWeight() {
        return goalWeight;
    }

    public void setGoalWeight(String goalWeight) {
        this.goalWeight = goalWeight;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
