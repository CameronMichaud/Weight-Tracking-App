package com.example.cs_360_weight_tracking_app_cameron_michaud;

import static android.Manifest.permission.READ_PHONE_NUMBERS;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.READ_SMS;
import static android.Manifest.permission.SEND_SMS;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.NumberPicker;
import android.widget.Toast;


public class WeightDetailActivity extends AppCompatActivity {

    private NumberPicker weight1, weight2, weight3;
    private DatePicker Date;

    private ImageButton deleteButton;
    private Cell selectedCell;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_detail);
        
        initWidgets();
        checkForEditCell();
    }

    private void checkForEditCell() {
        Intent previousIntent = getIntent();

        int passedCellID = previousIntent.getIntExtra(Cell.WEIGHT_EDIT_EXTRA, -1);
        selectedCell = Cell.getCellForID(passedCellID);

        if (selectedCell != null) { // If editing, populate with selected cell's info
            String weight = selectedCell.getWeight();

            weight1.setValue(Integer.parseInt(String.valueOf(weight.charAt(0))));
            weight2.setValue(Integer.parseInt(String.valueOf(weight.charAt(1))));
            weight3.setValue(Integer.parseInt(String.valueOf(weight.charAt(2))));

            String date = selectedCell.getDate();

            String[] dateFormat = date.split("/");
            int year = Integer.parseInt(dateFormat[2]);
            int month = Integer.parseInt(dateFormat[0]);
            int day = Integer.parseInt(dateFormat[1]);

            Date.init(year, month, day, null);

        }
        else { // Nothing to delete
            deleteButton.setVisibility(View.INVISIBLE);
        }
    }

    private void initWidgets() {
        deleteButton = (ImageButton) findViewById(R.id.deleteCellBt);

        weight1 = (NumberPicker) findViewById(R.id.weightPick1);
        weight2 = (NumberPicker) findViewById(R.id.weightPick2);
        weight3 = (NumberPicker) findViewById(R.id.weightPick3);

        weight1.setMinValue(1);
        weight2.setMinValue(1);
        weight3.setMinValue(1);

        weight1.setMaxValue(9);
        weight2.setMaxValue(9);
        weight3.setMaxValue(9);

        Date = (DatePicker) findViewById(R.id.datePicker);
    }

    public void saveWeight(View view) {

        // Create sqLiteManager to save cells & cell changes to
        WeightManager weightManager = WeightManager.instanceOfDatabase(this);

        // Get DateView items
        int month = Date.getMonth();
        int day = Date.getDayOfMonth();
        int year = Date.getYear();
        String sep = "/";

        // Create String Builder to Combine Strings
        StringBuilder str = new StringBuilder();

        // Get Date
        String date = String.valueOf(str.append(month).append(sep).append(day).append(sep).append(year));
        str.setLength(0);
        Log.d("Date", "Date: " + date);

        // Get Weight
        String weight = String.valueOf(str.append(weight1.getValue()).append(weight2.getValue()).append(weight3.getValue()).append(" lbs"));
        Log.d("Weight", "Weight: " + weight);

        if(selectedCell == null)
        { // Creating new cell
            int id = Cell.cellArrayList.size();
            String deleted = "false"; // Don't delete the new thing

            Cell newWeight = new Cell(id, date, weight, deleted, MainActivity.master_user.getUsername());
            //Cell.cellArrayList.add(newWeight);
            weightManager.addWeightToDatabase(newWeight);
        }
        else { // Editing a cell
            selectedCell.setDate(date);
            selectedCell.setWeight(weight);
            selectedCell.setDeleted("false"); // This might work?

            weightManager.updateWeightInDatabase(selectedCell);
        }

        checkGoal();

        // Return to daily weights and update the ListView
        Intent dailyWeightsIntent = new Intent(this, DailyWeightsActivity.class);
        startActivity(dailyWeightsIntent);
    }

    public void deleteWeight(View view) {
        selectedCell.setDeleted("true");

        // Create sqLiteManager to save cells & cell changes to
        WeightManager sqLiteManager = WeightManager.instanceOfDatabase(this);
        //sqLiteManager.updateWeightInDatabase(selectedCell);
        sqLiteManager.removeWeightInDatabse(selectedCell);
        finish();
    }

    public void checkGoal() {
        Log.d("PHONENUMBER: ", "Entered checkGoal()");
        // Check if new weight meets goal, send SMS is possible if so
        GoalManager goalManager = GoalManager.instanceOfDatabase(this);
        WeightManager weightManager = WeightManager.instanceOfDatabase(this);

        String lastWeight = weightManager.getWeight(MainActivity.master_user.getUsername());
        Log.d("LASTWEIGHT: ", lastWeight);
        Log.d("USERNAME: ", MainActivity.master_user.getUsername());
        String goalWeight = goalManager.getGoal().getGoalWeight();
        Log.d("goalWeight: ", goalWeight);

        lastWeight = lastWeight.substring(0, 3);
        goalWeight = goalWeight.substring(0, 3);

        Log.d("LASTWEIGHT: ", lastWeight);


        int lWeight = Integer.parseInt(lastWeight);
        int gWeight = Integer.parseInt(goalWeight);

        if (lWeight < gWeight || lWeight == gWeight) {
            // TODO: Make this work, break if goal doesn't exist,
            // Otherwise check sms permissions then send, tada, done
            if (ActivityCompat.checkSelfPermission(this, SEND_SMS) ==
                    PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, READ_SMS) ==
                    PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                    READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                Log.d("PHONENUMBER: ", "Before SMS Call");
                SmsManager smsManager = SmsManager.getDefault();
                Log.d("PHONENUMBER: ", MainActivity.phoneNumber);
                
                smsManager.sendTextMessage(MainActivity.phoneNumber, null, "Weight Goal Reached! Congratulations!", null, null);
            }

            else {
                Toast.makeText(WeightDetailActivity.this, "Weight Goal Reached!", Toast.LENGTH_SHORT).show();
            }
        }
    }

}