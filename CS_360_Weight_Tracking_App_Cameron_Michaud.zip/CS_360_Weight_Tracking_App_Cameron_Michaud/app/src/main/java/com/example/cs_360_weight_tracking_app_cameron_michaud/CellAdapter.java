package com.example.cs_360_weight_tracking_app_cameron_michaud;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class CellAdapter extends ArrayAdapter<Cell> {

    public CellAdapter(Context context, List<Cell> cells) {
        super(context, 0, cells);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Cell cell = getItem(position);
        if(convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.grid_cell, parent, false);

        TextView date = convertView.findViewById(R.id.cellDate);
        TextView weight = convertView.findViewById(R.id.cellWeight);

        // Set data to text
        date.setText(cell.getDate());
        weight.setText(cell.getWeight());

        return convertView;
    }
}
