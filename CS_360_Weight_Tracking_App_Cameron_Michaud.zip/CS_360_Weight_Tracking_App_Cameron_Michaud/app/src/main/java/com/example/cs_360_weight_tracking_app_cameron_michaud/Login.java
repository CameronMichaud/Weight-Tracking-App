package com.example.cs_360_weight_tracking_app_cameron_michaud;

import java.util.ArrayList;

public class Login {
    public static ArrayList<Login> cellArrayList = new ArrayList<>();

    private String username;
    private String password;

    //DELETE ME: public static String PASSWORD_EDIT_EXTRA = "PasswordEdit";

    public Login(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
