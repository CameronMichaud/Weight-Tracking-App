package com.example.cs_360_weight_tracking_app_cameron_michaud;

import static android.Manifest.permission.READ_PHONE_NUMBERS;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.READ_SMS;
import static android.Manifest.permission.SEND_SMS;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import static android.Manifest.permission.READ_PHONE_NUMBERS;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.READ_SMS;
import static android.Manifest.permission.SEND_SMS;

public class MainActivity extends AppCompatActivity {
    private Button login, create;
    private EditText username_btn, password_btn;
    private TextView usernameTextView;
    public String username, password = "";

    public static Login master_user = new Login("", "");
    BottomNavigationView bottomNavigationView;

    public static String phoneNumber = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initWidgets();
        checkAndRequestPermissions();
    }

    private void initWidgets() {
        login = (Button) findViewById(R.id.bt_login);
        create = (Button) findViewById(R.id.bt_create_account);
        login.setEnabled(false);
        login.setTextColor(Color.LTGRAY);
        create.setEnabled(false);
        create.setTextColor(Color.LTGRAY);

        username_btn = (EditText) findViewById(R.id.bt_username);
        password_btn = (EditText) findViewById(R.id.bt_pass);
        username = String.valueOf(username_btn.getText());
        password = String.valueOf(password_btn.getText());

        usernameTextView = (TextView) findViewById(R.id.usernameDisplayText);
        usernameTextView.setText(master_user.getUsername());

        bottomNavigationView = findViewById(R.id.bottom_nav);
        bottomNavigationView.setSelectedItemId(R.id.homeScreen);

        bottomNavigationView.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.dailyWeightScreen) {
                    startActivity(new Intent(getApplicationContext(), DailyWeightsActivity.class));
                    overridePendingTransition(0,0);
                    return true;
                }
                else if (item.getItemId() == R.id.homeScreen) {
                    return true;
                }
                else if (item.getItemId() == R.id.goalWeightScreen) {
                    startActivity(new Intent(getApplicationContext(), GoalActivity.class));
                    overridePendingTransition(0,0);
                    return true;
                }
                return false;
            }
        });

        username_btn.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkEmpty();
                Log.d("Button","Button Checked");
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        password_btn.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkEmpty();
                Log.d("Button","Button Checked");
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    public void checkEmpty() {
        String username = username_btn.getText().toString();
        String password = password_btn.getText().toString();

        if (username.equals("") || password.equals("")) {
            login.setEnabled(false);
            create.setEnabled(false);
            login.setTextColor(Color.LTGRAY);
            create.setTextColor(Color.LTGRAY);

            Log.d("Button","Button Disabled");
        } else {
            login.setEnabled(true);
            create.setEnabled(true);
            login.setTextColor(Color.WHITE);
            create.setTextColor(Color.WHITE);
            Log.d("Button","Button Enabled");
        }
    }

    public void createLogin(View view) {
        LoginManager loginManager = LoginManager.instanceOfDatabase(this);

        String username = String.valueOf(username_btn.getText());
        String password = String.valueOf(password_btn.getText());

        Login newLogin = new Login(username, password);
        master_user = newLogin;

        loginManager.addLoginToDatabase(newLogin);

        // Automatically pass user to daily weights (most common reference)
        Intent dailyWeightsIntent = new Intent(this, DailyWeightsActivity.class);
        startActivity(dailyWeightsIntent);
    }

    public void loginUser(View view) {
        LoginManager loginManager = LoginManager.instanceOfDatabase(this);

        String username = String.valueOf(username_btn.getText());
        String password = String.valueOf(password_btn.getText());
        Log.d("FIELD", "User, Pass: " + username + " " + password);

        boolean result = loginManager.login(username, password);
        //Log.d("FIELD", "result: User, Pass: " + result.getUsername() + result.getPassword());

        Log.d("FIELD", "Master_user: User, Pass: " + master_user.getUsername() + master_user.getPassword());
        if (!result) { // Default text == fail, otherwise successful
            Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
        }
        else {
            master_user = new Login(username, password);
            usernameTextView.setText(master_user.getUsername());
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
        }

        Log.d("FIELD", "Master_user: User, Pass: " + master_user.getUsername() + master_user.getPassword());

        // Automatically pass user to daily weights (most common reference)
        Intent dailyWeightsIntent = new Intent(this, DailyWeightsActivity.class);
        startActivity(dailyWeightsIntent);
    }

    public void logout(View view) {
        master_user.setUsername("");
        master_user.setPassword("");
        usernameTextView.setText(master_user.getUsername());
        Toast.makeText(this, "Logout Successful", Toast.LENGTH_SHORT).show();

        Log.d("FIELD", "Master_user: User, Pass: " + master_user.getUsername() + master_user.getPassword());
    }

    private void checkAndRequestPermissions() {
        if (ActivityCompat.checkSelfPermission(this, SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, READ_SMS) ==
                PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {

            TelephonyManager telephonyManager = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
            phoneNumber = telephonyManager.getLine1Number();
            Log.d("PHONENUMBER: ", phoneNumber);

            Toast.makeText(MainActivity.this, "Permissions Granted", Toast.LENGTH_SHORT).show();
        }
        else {
            requestPermission();
        }
    }
    private void requestPermission() {
        requestPermissions(new String[]{SEND_SMS, READ_SMS, READ_PHONE_NUMBERS, READ_PHONE_STATE}, 100);
    }

    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 100:
                if (ActivityCompat.checkSelfPermission(this, SEND_SMS) !=
                        PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, READ_SMS) !=
                        PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                        READ_PHONE_NUMBERS) != PackageManager.PERMISSION_GRANTED &&
                        ActivityCompat.checkSelfPermission(this, READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED ) {
                    return;
                }
                TelephonyManager telephonyManager = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
                phoneNumber = telephonyManager.getLine1Number();
                Log.d("PHONENUMBER: ", phoneNumber);
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + requestCode);
        }
    }
}