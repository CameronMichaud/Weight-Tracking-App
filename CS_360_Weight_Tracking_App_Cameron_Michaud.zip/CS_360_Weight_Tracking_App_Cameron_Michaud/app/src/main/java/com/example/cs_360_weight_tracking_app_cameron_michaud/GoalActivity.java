package com.example.cs_360_weight_tracking_app_cameron_michaud;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class GoalActivity extends AppCompatActivity {

    public static GoalWeight weight = new GoalWeight("Tap to Set", "");
    private Button weightDisplay;


    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);

        initWidgets();
        setWeight();
    }

    private void initWidgets() {
        weightDisplay = findViewById(R.id.weight_display);

        bottomNavigationView = findViewById(R.id.bottom_nav);
        bottomNavigationView.setSelectedItemId(R.id.goalWeightScreen);

        bottomNavigationView.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.homeScreen) {
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0,0);
                    return true;
                }
                else if (item.getItemId() == R.id.dailyWeightScreen) {
                    startActivity(new Intent(getApplicationContext(), DailyWeightsActivity.class));
                    overridePendingTransition(0,0);
                    return true;
                }
                else return item.getItemId() == R.id.goalWeightScreen;
            }
        });
    }
    public void removeWeight(String oldWeight) {
        GoalManager goalManager = GoalManager.instanceOfDatabase(this);

        GoalWeight gWeight = goalManager.getGoal();
        String goalWeight = gWeight.getGoalWeight();
        Log.d("FIELD", "Returned: " + goalWeight);

        if (!goalWeight.equals("null")) { // If prior goal existed, delete it
            goalManager.removeGoal(oldWeight);
        }
    }
    private void setWeight() {
        GoalManager goalManager = GoalManager.instanceOfDatabase(this);

        GoalWeight gWeight = goalManager.getGoal();
        String goalWeight = gWeight.getGoalWeight();
        Log.d("FIELD", "Returned: " + goalWeight);
        Log.d("FIELD", "Returned: " + gWeight.getGoalWeight() + " " + gWeight.getUsername());

        if (!goalWeight.equals("null") && gWeight.getUsername().equals(MainActivity.master_user.getUsername())) { // Set w/latest entry, or leave default
            weight = gWeight;
            Log.d("FIELD", "weight: " + weight.getGoalWeight());
        }
        else {
            weight = new GoalWeight("Tap to Set", "");
        }

        weightDisplay.setText(weight.getGoalWeight());
    }
    public void weightPickDialog(View view)
    {
        // Parameters
        GoalManager goalManager = GoalManager.instanceOfDatabase(this);

        RelativeLayout linearLayout = new RelativeLayout(this);

        final NumberPicker weight1 = new NumberPicker(this);
        final NumberPicker weight2 = new NumberPicker(this);
        final NumberPicker weight3 = new NumberPicker(this);

        weight1.setMinValue(1);
        weight2.setMinValue(1);
        weight3.setMinValue(1);

        weight1.setMaxValue(9);
        weight2.setMaxValue(9);
        weight3.setMaxValue(9);


        // Layout
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(50, 50);
        RelativeLayout.LayoutParams center = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        center.addRule(RelativeLayout.CENTER_HORIZONTAL);
        RelativeLayout.LayoutParams start = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        start.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        RelativeLayout.LayoutParams end = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        end.addRule(RelativeLayout.ALIGN_PARENT_END);

        linearLayout.setLayoutParams(params);
        linearLayout.addView(weight1,start);
        linearLayout.addView(weight2,center);
        linearLayout.addView(weight3,end);

        // Build
        AlertDialog.Builder goalPicker = new AlertDialog.Builder(this);

        goalPicker.setTitle("Set Goal Weight");
        goalPicker.setView(linearLayout);

        goalPicker.setPositiveButton("Set Goal", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                StringBuilder str = new StringBuilder();

                // Delete old weight, then add new one
                String newWeight = String.valueOf(str.append(weight1.getValue()).append(weight2.getValue()).append(weight3.getValue()).append(" lbs"));
                removeWeight(weight.getGoalWeight());
                goalManager.addGoalWeightToDatabase(new GoalWeight(newWeight, MainActivity.master_user.getUsername()));

                // Set weight display
                setWeight();

                // Notify User
                Toast.makeText(GoalActivity.this, "Goal Set!", Toast.LENGTH_SHORT).show();
            }
        });

        goalPicker.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });

        goalPicker.create().show();
    }
}