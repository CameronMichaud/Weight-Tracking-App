package com.example.cs_360_weight_tracking_app_cameron_michaud;

import android.util.Log;

import java.util.ArrayList;

public class Cell {
    public static ArrayList<Cell> cellArrayList = new ArrayList<>();

    private int id;
    private String date;
    private String weight;
    private String deleted;

    private String user;

    public static String WEIGHT_EDIT_EXTRA = "weightEdit";

    public Cell(int id, String date, String weight, String deleted, String user) {
        this.id = id;
        this.date = date;
        this.weight = weight;
        this.deleted = deleted;
        this.user = user;
    }

    public static Cell getCellForID(int passedCellID) {

        for (Cell cell : cellArrayList)
        {
            if(cell.getId() == passedCellID)
                return cell;
        }
        return null;
    }

    public static ArrayList<Cell> nonDeletedCells() { // Get all non-deleted cells to populate list
        ArrayList<Cell> nonDeleted = new ArrayList<>();
        for(Cell cell : cellArrayList) {
            Log.d("FIELD", "Master User at Array : " + MainActivity.master_user.getUsername());
            if(cell.getDeleted().equals("false") && cell.getUser().equals(MainActivity.master_user.getUsername())) {
                nonDeleted.add(cell);
            }
        }
        for(Cell cell : nonDeleted) {
            if (cell.getDeleted().equals("true")) {
                nonDeleted.remove(cell);
            }
        }

        // Non-deleted cells
        return nonDeleted;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getDeleted() {
        return deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
