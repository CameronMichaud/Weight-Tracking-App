package com.example.cs_360_weight_tracking_app_cameron_michaud;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class LoginManager extends SQLiteOpenHelper {

    private static LoginManager sqLiteManager;
    private static final String DATABASE_NAME = "LoginDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "Logins";
    private static final String COUNTER = "Counter";

    private static final String ID_FIELD = "id";
    private static final String USERNAME_FIELD = "username";
    private static final String PASSWORD_FIELD = "password";

    public LoginManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static LoginManager instanceOfDatabase(Context context) {
        if(sqLiteManager == null)
            sqLiteManager = new LoginManager(context);

        return sqLiteManager;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(USERNAME_FIELD)
                .append(" TEXT, ")
                .append(PASSWORD_FIELD)
                .append(" TEXT)");

        sqLiteDatabase.execSQL(sql.toString());



    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {

    }

    public void addLoginToDatabase(Login login) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Log.d("FIELD", "ADDING PASSWORD");
        ContentValues contentValues = new ContentValues();
        contentValues.put(USERNAME_FIELD, login.getUsername());
        Log.d("FIELD", "USERNAME: " + login.getUsername());
        contentValues.put(PASSWORD_FIELD, login.getPassword());
        Log.d("FIELD", "PASSWORD: " + login.getPassword());

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
    }

    public boolean login(String username, String password) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        //Login rejected = new Login("", "");

        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null)) {
            if(result.getCount() != 0) {
                while (result.moveToNext())
                {
                    String user = result.getString(1);
                    String pass = result.getString(2);
                    Log.d("FIELD", "Processing User, Pass: " + user + " " + pass);

                    if (username.equals(user) && password.equals(pass)) {
                        Log.d("FIELD", "LoginManager User, Pass: " + user + " " + pass);
                        return true;
                        //return new Login(user, pass);
                    }
                }
            }
        }
        return false;
        //return rejected;
    }
}
